"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { useAuth } from "@/context/auth-context"
import { DashboardHeader } from "@/components/dashboard-header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Skeleton } from "@/components/ui/skeleton"
import { BookOpen, Plus } from "lucide-react"

type Course = {
  _id: string
  title: string
  description: string
  thumbnail: string
  isPublished: boolean
  creator: {
    firstName: string
    lastName: string
  }
}

export default function AdminDashboardPage() {
  const { user, loading: authLoading, isAdmin } = useAuth()
  const [courses, setCourses] = useState<Course[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchCourses = async () => {
      if (!user || !isAdmin) return

      try {
        // For preview purposes when API is not available
        if (!process.env.NEXT_PUBLIC_API_URL) {
          console.warn("API URL is not defined. Using mock data for preview.")
          // Mock courses data
          const mockCourses = [
            {
              _id: "course-1",
              title: "Introduction to Web Development",
              description: "Learn the basics of HTML, CSS, and JavaScript",
              thumbnail: "/placeholder.svg?height=300&width=400",
              isPublished: true,
              creator: {
                firstName: "Admin",
                lastName: "User",
              },
            },
            {
              _id: "course-2",
              title: "Advanced React Patterns",
              description: "Master advanced React concepts and patterns",
              thumbnail: "/placeholder.svg?height=300&width=400",
              isPublished: true,
              creator: {
                firstName: "Admin",
                lastName: "User",
              },
            },
            {
              _id: "course-3",
              title: "Node.js Backend Development",
              description: "Build scalable backend services with Node.js",
              thumbnail: "/placeholder.svg?height=300&width=400",
              isPublished: false,
              creator: {
                firstName: "Admin",
                lastName: "User",
              },
            },
          ]

          setCourses(mockCourses)
          setLoading(false)
          return
        }

        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/admin/courses`, {
          credentials: "include",
        })

        if (res.ok) {
          const data = await res.json()
          setCourses(data)
        } else {
          console.error("Failed to fetch courses:", res.status)
        }
      } catch (error) {
        console.error("Error fetching courses:", error)
      } finally {
        setLoading(false)
      }
    }

    if (!authLoading) {
      fetchCourses()
    }
  }, [user, authLoading, isAdmin])

  if (authLoading) {
    return (
      <div className="flex min-h-screen flex-col">
        <DashboardHeader />
        <main className="flex-1 container py-10">
          <h1 className="text-3xl font-bold mb-6">Loading...</h1>
        </main>
      </div>
    )
  }

  if (!user || !isAdmin) {
    return (
      <div className="flex min-h-screen flex-col">
        <DashboardHeader />
        <main className="flex-1 container py-10">
          <div className="flex flex-col items-center justify-center h-[60vh] space-y-4">
            <h1 className="text-2xl font-bold">Access Denied</h1>
            <p className="text-muted-foreground">You don't have permission to access this page</p>
            <Button asChild>
              <Link href="/dashboard">Go to Dashboard</Link>
            </Button>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader />
      <main className="flex-1 container py-10">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
            <p className="text-muted-foreground">Manage courses, users, and content</p>
          </div>
          <Button asChild>
            <Link href="/admin/courses/create">
              <Plus className="mr-2 h-4 w-4" /> Create Course
            </Link>
          </Button>
        </div>

        <div className="grid gap-6 md:grid-cols-3 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Courses</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{loading ? "..." : courses.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Published Courses</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{loading ? "..." : courses.filter((c) => c.isPublished).length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">--</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="all" className="space-y-4">
          <TabsList>
            <TabsTrigger value="all">All Courses</TabsTrigger>
            <TabsTrigger value="published">Published</TabsTrigger>
            <TabsTrigger value="drafts">Drafts</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            {loading ? (
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {[1, 2, 3].map((i) => (
                  <Card key={i} className="overflow-hidden">
                    <CardHeader className="p-0">
                      <Skeleton className="h-48 rounded-none" />
                    </CardHeader>
                    <CardContent className="p-6">
                      <Skeleton className="h-6 w-2/3 mb-2" />
                      <Skeleton className="h-4 w-full mb-4" />
                      <Skeleton className="h-4 w-full" />
                    </CardContent>
                    <CardFooter className="p-6 pt-0">
                      <Skeleton className="h-10 w-full" />
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : courses.length > 0 ? (
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {courses.map((course) => (
                  <Card key={course._id} className="overflow-hidden">
                    <CardHeader className="p-0">
                      {course.thumbnail ? (
                        <img
                          src={course.thumbnail || "/placeholder.svg"}
                          alt={course.title}
                          className="h-48 w-full object-cover"
                        />
                      ) : (
                        <div className="h-48 w-full bg-muted flex items-center justify-center">
                          <BookOpen className="h-12 w-12 text-muted-foreground/50" />
                        </div>
                      )}
                      {!course.isPublished && (
                        <div className="absolute top-2 right-2 bg-yellow-500 text-white text-xs px-2 py-1 rounded">
                          Draft
                        </div>
                      )}
                    </CardHeader>
                    <CardContent className="p-6">
                      <CardTitle className="mb-2">{course.title}</CardTitle>
                      <CardDescription className="line-clamp-2 mb-4">{course.description}</CardDescription>
                    </CardContent>
                    <CardFooter className="p-6 pt-0 flex gap-2">
                      <Button asChild variant="outline" className="flex-1">
                        <Link href={`/admin/courses/${course._id}`}>Edit</Link>
                      </Button>
                      <Button asChild className="flex-1">
                        <Link href={`/admin/courses/${course._id}/content`}>Content</Link>
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 border rounded-lg bg-muted/30">
                <BookOpen className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
                <h3 className="text-xl font-medium mb-2">No courses yet</h3>
                <p className="text-muted-foreground mb-4">You haven't created any courses yet.</p>
                <Button asChild>
                  <Link href="/admin/courses/create">Create Course</Link>
                </Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="published">
            {loading ? (
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {[1, 2].map((i) => (
                  <Card key={i} className="overflow-hidden">
                    <CardHeader className="p-0">
                      <Skeleton className="h-48 rounded-none" />
                    </CardHeader>
                    <CardContent className="p-6">
                      <Skeleton className="h-6 w-2/3 mb-2" />
                      <Skeleton className="h-4 w-full mb-4" />
                      <Skeleton className="h-4 w-full" />
                    </CardContent>
                    <CardFooter className="p-6 pt-0">
                      <Skeleton className="h-10 w-full" />
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : courses.filter((c) => c.isPublished).length > 0 ? (
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {courses
                  .filter((course) => course.isPublished)
                  .map((course) => (
                    <Card key={course._id} className="overflow-hidden">
                      <CardHeader className="p-0">
                        {course.thumbnail ? (
                          <img
                            src={course.thumbnail || "/placeholder.svg"}
                            alt={course.title}
                            className="h-48 w-full object-cover"
                          />
                        ) : (
                          <div className="h-48 w-full bg-muted flex items-center justify-center">
                            <BookOpen className="h-12 w-12 text-muted-foreground/50" />
                          </div>
                        )}
                      </CardHeader>
                      <CardContent className="p-6">
                        <CardTitle className="mb-2">{course.title}</CardTitle>
                        <CardDescription className="line-clamp-2 mb-4">{course.description}</CardDescription>
                      </CardContent>
                      <CardFooter className="p-6 pt-0 flex gap-2">
                        <Button asChild variant="outline" className="flex-1">
                          <Link href={`/admin/courses/${course._id}`}>Edit</Link>
                        </Button>
                        <Button asChild className="flex-1">
                          <Link href={`/admin/courses/${course._id}/content`}>Content</Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
              </div>
            ) : (
              <div className="text-center py-12 border rounded-lg bg-muted/30">
                <h3 className="text-xl font-medium mb-2">No published courses</h3>
                <p className="text-muted-foreground">You don't have any published courses yet.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="drafts">
            {loading ? (
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {[1, 2].map((i) => (
                  <Card key={i} className="overflow-hidden">
                    <CardHeader className="p-0">
                      <Skeleton className="h-48 rounded-none" />
                    </CardHeader>
                    <CardContent className="p-6">
                      <Skeleton className="h-6 w-2/3 mb-2" />
                      <Skeleton className="h-4 w-full mb-4" />
                      <Skeleton className="h-4 w-full" />
                    </CardContent>
                    <CardFooter className="p-6 pt-0">
                      <Skeleton className="h-10 w-full" />
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : courses.filter((c) => !c.isPublished).length > 0 ? (
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {courses
                  .filter((course) => !course.isPublished)
                  .map((course) => (
                    <Card key={course._id} className="overflow-hidden">
                      <CardHeader className="p-0">
                        {course.thumbnail ? (
                          <img
                            src={course.thumbnail || "/placeholder.svg"}
                            alt={course.title}
                            className="h-48 w-full object-cover"
                          />
                        ) : (
                          <div className="h-48 w-full bg-muted flex items-center justify-center">
                            <BookOpen className="h-12 w-12 text-muted-foreground/50" />
                          </div>
                        )}
                      </CardHeader>
                      <CardContent className="p-6">
                        <CardTitle className="mb-2">{course.title}</CardTitle>
                        <CardDescription className="line-clamp-2 mb-4">{course.description}</CardDescription>
                      </CardContent>
                      <CardFooter className="p-6 pt-0 flex gap-2">
                        <Button asChild variant="outline" className="flex-1">
                          <Link href={`/admin/courses/${course._id}`}>Edit</Link>
                        </Button>
                        <Button asChild className="flex-1">
                          <Link href={`/admin/courses/${course._id}/content`}>Content</Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
              </div>
            ) : (
              <div className="text-center py-12 border rounded-lg bg-muted/30">
                <h3 className="text-xl font-medium mb-2">No draft courses</h3>
                <p className="text-muted-foreground">You don't have any draft courses yet.</p>
                <Button asChild>
                  <Link href="/admin/courses/create">Create Course</Link>
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
