"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { useAuth } from "@/context/auth-context"
import { DashboardHeader } from "@/components/dashboard-header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Skeleton } from "@/components/ui/skeleton"
import { BookOpen, Clock } from "lucide-react"

type EnrolledCourse = {
  id: string
  title: string
  description: string
  thumbnail: string
  creator: {
    firstName: string
    lastName: string
  }
  progress: {
    lastAccessedAt: string
    currentSectionId: string
    currentUnitId: string
    currentChapterId: string
    completedChapters: number
  }
}

export default function DashboardPage() {
  const { user, loading: authLoading } = useAuth()
  const [enrolledCourses, setEnrolledCourses] = useState<EnrolledCourse[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchEnrolledCourses = async () => {
      if (!user) return

      try {
        // For preview purposes when API is not available
        if (!process.env.NEXT_PUBLIC_API_URL) {
          console.warn("API URL is not defined. Using mock data for preview.")
          // Mock enrolled courses data
          const mockCourses = [
            {
              id: "course-1",
              title: "Introduction to Web Development",
              description: "Learn the basics of HTML, CSS, and JavaScript",
              thumbnail: "/placeholder.svg?height=300&width=400",
              creator: {
                firstName: "John",
                lastName: "Doe",
              },
              progress: {
                lastAccessedAt: new Date().toISOString(),
                currentSectionId: "section-1",
                currentUnitId: "unit-1",
                currentChapterId: "chapter-1",
                completedChapters: 35,
              },
            },
            {
              id: "course-2",
              title: "Advanced React Patterns",
              description: "Master advanced React concepts and patterns",
              thumbnail: "/placeholder.svg?height=300&width=400",
              creator: {
                firstName: "Jane",
                lastName: "Smith",
              },
              progress: {
                lastAccessedAt: new Date(Date.now() - 86400000).toISOString(), // yesterday
                currentSectionId: "section-1",
                currentUnitId: "unit-2",
                currentChapterId: "chapter-3",
                completedChapters: 60,
              },
            },
          ]

          setEnrolledCourses(mockCourses)
          setLoading(false)
          return
        }

        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/user/courses`, {
          credentials: "include",
        })

        if (res.ok) {
          const data = await res.json()
          setEnrolledCourses(data)
        } else {
          console.error("Failed to fetch enrolled courses:", res.status)
        }
      } catch (error) {
        console.error("Error fetching enrolled courses:", error)
      } finally {
        setLoading(false)
      }
    }

    if (!authLoading) {
      fetchEnrolledCourses()
    }
  }, [user, authLoading])

  if (authLoading) {
    return (
      <div className="flex min-h-screen flex-col">
        <DashboardHeader />
        <main className="flex-1 container py-10">
          <h1 className="text-3xl font-bold mb-6">Loading...</h1>
        </main>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="flex min-h-screen flex-col">
        <DashboardHeader />
        <main className="flex-1 container py-10">
          <div className="flex flex-col items-center justify-center h-[60vh] space-y-4">
            <h1 className="text-2xl font-bold">You need to be logged in</h1>
            <p className="text-muted-foreground">Please log in to view your dashboard</p>
            <Button asChild>
              <Link href="/auth/login">Login</Link>
            </Button>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader />
      <main className="flex-1 container py-10">
        <h1 className="text-3xl font-bold mb-2">Welcome, {user.firstName}!</h1>
        <p className="text-muted-foreground mb-8">Track your learning progress and continue your courses.</p>

        <div className="space-y-8">
          <div>
            <h2 className="text-2xl font-bold mb-4">My Courses</h2>
            {loading ? (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {[1, 2, 3].map((i) => (
                  <Card key={i} className="overflow-hidden">
                    <CardHeader className="p-0">
                      <Skeleton className="h-48 rounded-none" />
                    </CardHeader>
                    <CardContent className="p-6">
                      <Skeleton className="h-6 w-2/3 mb-2" />
                      <Skeleton className="h-4 w-full mb-4" />
                      <Skeleton className="h-4 w-full" />
                    </CardContent>
                    <CardFooter className="p-6 pt-0">
                      <Skeleton className="h-10 w-full" />
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : enrolledCourses.length > 0 ? (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {enrolledCourses.map((course) => (
                  <Card key={course.id} className="overflow-hidden">
                    <CardHeader className="p-0">
                      {course.thumbnail ? (
                        <img
                          src={course.thumbnail || "/placeholder.svg"}
                          alt={course.title}
                          className="h-48 w-full object-cover"
                        />
                      ) : (
                        <div className="h-48 w-full bg-muted flex items-center justify-center">
                          <BookOpen className="h-12 w-12 text-muted-foreground/50" />
                        </div>
                      )}
                    </CardHeader>
                    <CardContent className="p-6">
                      <CardTitle className="mb-2">{course.title}</CardTitle>
                      <CardDescription className="line-clamp-2 mb-4">{course.description}</CardDescription>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span className="font-medium">{course.progress.completedChapters}%</span>
                        </div>
                        <Progress value={course.progress.completedChapters} className="h-2" />
                      </div>
                    </CardContent>
                    <CardFooter className="p-6 pt-0">
                      <Button asChild className="w-full">
                        <Link
                          href={`/courses/${course.id}/sections/${course.progress.currentSectionId}/units/${course.progress.currentUnitId}/chapters/${course.progress.currentChapterId}`}
                        >
                          Continue Learning
                        </Link>
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 border rounded-lg bg-muted/30">
                <BookOpen className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
                <h3 className="text-xl font-medium mb-2">No courses yet</h3>
                <p className="text-muted-foreground mb-4">You haven't enrolled in any courses yet.</p>
                <Button asChild>
                  <Link href="/courses">Browse Courses</Link>
                </Button>
              </div>
            )}
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-4">Recently Viewed</h2>
            {loading ? (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {[1, 2].map((i) => (
                  <Card key={i}>
                    <CardContent className="p-6">
                      <Skeleton className="h-6 w-2/3 mb-2" />
                      <Skeleton className="h-4 w-full mb-4" />
                      <Skeleton className="h-4 w-1/2" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : enrolledCourses.length > 0 ? (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {enrolledCourses
                  .sort(
                    (a, b) =>
                      new Date(b.progress.lastAccessedAt).getTime() - new Date(a.progress.lastAccessedAt).getTime(),
                  )
                  .slice(0, 3)
                  .map((course) => (
                    <Card key={course.id}>
                      <CardContent className="p-6">
                        <CardTitle className="mb-2">{course.title}</CardTitle>
                        <CardDescription className="line-clamp-2 mb-4">{course.description}</CardDescription>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <Clock className="h-4 w-4 mr-1" />
                          <span>Last accessed: {new Date(course.progress.lastAccessedAt).toLocaleDateString()}</span>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            ) : (
              <div className="text-center py-8 border rounded-lg bg-muted/30">
                <p className="text-muted-foreground">No recently viewed courses</p>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
