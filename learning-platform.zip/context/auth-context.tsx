"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"
import { useRouter } from "next/navigation"

type User = {
  _id: string
  email: string
  firstName: string
  lastName: string
  role: "admin" | "learner"
}

type AuthContextType = {
  user: User | null
  loading: boolean
  login: (email: string, password: string) => Promise<void>
  register: (userData: RegisterData) => Promise<void>
  logout: () => Promise<void>
  isAdmin: boolean
}

type RegisterData = {
  email: string
  password: string
  firstName: string
  lastName: string
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  // Check if user is logged in
  useEffect(() => {
    const checkAuth = async () => {
      try {
        // Check if API URL is defined
        if (!process.env.NEXT_PUBLIC_API_URL) {
          console.warn("API URL is not defined. Using mock user for preview.")
          // For preview purposes, set a mock user
          setUser({
            _id: "mock-id",
            email: "user@example.com",
            firstName: "Demo",
            lastName: "User",
            role: "learner",
          })
          setLoading(false)
          return
        }

        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/auth/me`, {
          credentials: "include",
        })

        if (res.ok) {
          const userData = await res.json()
          setUser(userData)
        } else {
          // Handle non-OK responses without throwing an error
          console.log(`Auth check failed with status: ${res.status}`)
          setUser(null)
        }
      } catch (error) {
        console.error("Auth check error:", error)
        setUser(null)
      } finally {
        setLoading(false)
      }
    }

    checkAuth()
  }, [])

  // Login function
  const login = async (email: string, password: string) => {
    setLoading(true)
    try {
      // For preview purposes when API is not available
      if (!process.env.NEXT_PUBLIC_API_URL) {
        console.warn("API URL is not defined. Using mock login for preview.")
        // Mock successful login
        const mockUser = {
          _id: "mock-id",
          email,
          firstName: "Demo",
          lastName: "User",
          role: email.includes("admin") ? "admin" : "learner",
        }

        setUser(mockUser)

        // Redirect based on role
        if (mockUser.role === "admin") {
          router.push("/admin/dashboard")
        } else {
          router.push("/dashboard")
        }

        setLoading(false)
        return
      }

      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/auth/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
        credentials: "include",
      })

      if (!res.ok) {
        const error = await res.json()
        throw new Error(error.message || "Login failed")
      }

      const userData = await res.json()
      setUser(userData)

      // Redirect based on role
      if (userData.role === "admin") {
        router.push("/admin/dashboard")
      } else {
        router.push("/dashboard")
      }
    } catch (error) {
      console.error("Login error:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  // Register function
  const register = async (userData: RegisterData) => {
    setLoading(true)
    try {
      // For preview purposes when API is not available
      if (!process.env.NEXT_PUBLIC_API_URL) {
        console.warn("API URL is not defined. Using mock registration for preview.")
        // Mock successful registration
        const mockUser = {
          _id: "mock-id",
          email: userData.email,
          firstName: userData.firstName,
          lastName: userData.lastName,
          role: "learner",
        }

        setUser(mockUser)
        router.push("/dashboard")
        setLoading(false)
        return
      }

      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/auth/register`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(userData),
        credentials: "include",
      })

      if (!res.ok) {
        const error = await res.json()
        throw new Error(error.message || "Registration failed")
      }

      const user = await res.json()
      setUser(user)
      router.push("/dashboard")
    } catch (error) {
      console.error("Register error:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  // Logout function
  const logout = async () => {
    try {
      // For preview purposes when API is not available
      if (!process.env.NEXT_PUBLIC_API_URL) {
        console.warn("API URL is not defined. Using mock logout for preview.")
        setUser(null)
        router.push("/auth/login")
        return
      }

      await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/auth/logout`, {
        method: "POST",
        credentials: "include",
      })
      setUser(null)
      router.push("/auth/login")
    } catch (error) {
      console.error("Logout error:", error)
      // Still logout the user on the client side even if the API call fails
      setUser(null)
      router.push("/auth/login")
    }
  }

  const isAdmin = user?.role === "admin"

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        login,
        register,
        logout,
        isAdmin,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
